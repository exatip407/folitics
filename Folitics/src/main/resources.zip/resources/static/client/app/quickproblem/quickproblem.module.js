(function(angular) {
	'use strict';

	angular.module('governProject.quickproblem', []).config(Configure);

	Configure.$inject = [ '$routeProvider' ];

	function Configure($locationProvider, $routeProvider) {
	}

})(window.angular);