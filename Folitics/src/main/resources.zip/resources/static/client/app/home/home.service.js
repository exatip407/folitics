﻿(function(angular) {

	'use strict';

	function HomeService($http, $q) {
		
	}

	HomeService.$inject = [ '$http', '$q' ];

	angular.module('governProject.home').service('HomeService', HomeService);

})(window.angular);