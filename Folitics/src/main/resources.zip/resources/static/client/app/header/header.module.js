(function (angular) {
    'use strict';

    angular.module('governProject.header', []).config(Configure);

    Configure.$inject = ['$routeProvider'];

    function Configure($locationProvider, $routeProvider) {
      
   
        
    }

})(window.angular);