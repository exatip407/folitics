﻿(function(angular) {

	'use strict';

	function CategoryController($http, $scope, CategoryService) {

	}

	CategoryController.$inject = [ '$http', '$scope', 'CategoryService' ];

	angular.module('governProject.category').controller('CategoryController',
	CategoryController);

})(window.angular);