(function(angular) {

	'use strict';

	function trackPromiseService($http, $q) {

		
			this.categories = function(){
				
		};
	}

	trackPromiseService.$inject = [ '$http', '$q' ];

	angular.module('governProject.trackPromise').service('trackPromiseService', trackPromiseService);

})(window.angular);