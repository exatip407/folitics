
(function (angular) {
    'use strict';

    angular.module('governProject.trackPromise', []).config(Configure);

    Configure.$inject = ['$routeProvider'];

    function Configure($locationProvider, $routeProvider) { 
    }

})(window.angular);