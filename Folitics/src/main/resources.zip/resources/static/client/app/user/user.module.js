
(function (angular) {
    'use strict';

    angular.module('governProject.user', []).config(Configure);

    Configure.$inject = ['$routeProvider'];

    function Configure($locationProvider, $routeProvider) {
      
   
        
    }

})(window.angular);