
(function (angular) {
    'use strict';

    angular.module('governProject.fact', []).config(Configure);

    Configure.$inject = ['$routeProvider'];

    function Configure($locationProvider, $routeProvider) {
      
    }

})(window.angular);